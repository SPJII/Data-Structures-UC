// Wheel.cpp
#include "Header.h"
#include <cstdlib>
#include <ctime>

//Eder

Wheel::Wheel(int minVal, int maxVal) : minVal(minVal), maxVal(maxVal) {
  
}

int Wheel::spin() {
 

void Wheel::changeRange(int newMin, int newMax) {

}

//Steven

Player::Player(int initialMoney) : money(initialMoney) {}

int Player::getMoney() const {
    return money;
}

void Player::setMoney(int newMoney) {
    money = newMoney;
}

void Player::adjustMoney(int amount) {
    money += amount;
}

void Player::placeBet(int betAmount) {
    bet = betAmount;
}

int Player::getBet() const {
    return bet;
}

Wheel& Player::getWheel() {
    return wheel;
}
