
#pragma once

class Wheel {
public:
    Wheel(int minVal = 1, int maxVal = 10);

    int spin();
    void changeRange(int newMin, int newMax);

private:
    int minVal;
    int maxVal;
};


class Player {
public:
    Player(int initialMoney = 1000);

    int getMoney() const;
    void setMoney(int newMoney);
    void adjustMoney(int amount);
    void placeBet(int betAmount);
    int getBet() const;
    Wheel& getWheel();

private:
    int money;
    int bet;
    Wheel wheel;
};
