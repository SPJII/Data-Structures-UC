// Wheel.cpp
#include "Header.h"
#include <cstdlib>
#include <ctime>

using namespace std;
//Eder

Wheel::Wheel(int minVal, int maxVal) : minVal(minVal), maxVal(maxVal) {
  
}

int Wheel::spin() {
    //initialize the random number generator with the current time as the seed. this will ensure new numbers are generated each time this method is called
    srand(time(0));
    //generate random number between min and max values set on this class
    int random = rand() % (maxVal + 1 - minVal) + minVal;
    return random;
    
}
 

void Wheel::changeRange(int min, int max) {
    this->minVal = min;
    this->maxVal = max;
}

//Steven

Player::Player(int initialMoney) : money(initialMoney) {}

int Player::getMoney() const {
    return money;
}

void Player::setMoney(int newMoney) {
    money = newMoney;
}

void Player::adjustMoney(int amount) {
    money += amount;
}

void Player::placeBet(int betAmount) {
    bet = betAmount;
}

int Player::getBet() const {
    return bet;
}

Wheel& Player::getWheel() {
    return wheel;
}
