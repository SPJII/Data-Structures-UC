#pragma once
#include <iostream> //Moved iostream here
class Wheel {
public:
    Wheel(int minVal = 1, int maxVal = 10);
    int spin();// use this for general spinning
    void changeRange(int newMin, int newMax);

private:
    int minVal;
    int maxVal;
};


class Player {
public:
    Player(int initialMoney = 1000);
    int getMoney() const;
    void setMoney(int newMoney);
    void adjustMoney(int amount);
    void placeBet(int betAmount);
    int getBet() const;
    Wheel& getWheel();

private:
    int money;
    int bet;
    Wheel wheel;
};

class House {
public:
    House();
    int wagerSame(Player&); //if player wins, return true.
    int wagerHalve(Player&);
    int wagerDouble(Player&);
    Wheel& getWheel();
    int getGameType();
private:
    Wheel wheel;
//    int gameType; //This will track if a double, half or other is used. 

};