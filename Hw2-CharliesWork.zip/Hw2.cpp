
#include "Header.h"

int main() {
    // Initialize the game
    Player player;
    House house;

    // Main game loop
    while (player.getMoney() > 0) {
        int betAmount;
        int result;
        // Get the bet amount from the player
        do {
            std::cout << "Enter your bet (between 6 and 20): ";
            std::cin >> betAmount;
        } while (betAmount < 6 || betAmount > 20);

        // Ask the player whether to double, halve, or keep the same wager
        std::string betChange;
        std::cout << "Do you want to double, halve, or keep the same wager? ";
        std::cin >> betChange;
        if (betChange == "double") {
            player.placeBet(betAmount*2);
            result = house.wagerDouble(player);
        }
        else if (betChange == "halve") {
            player.placeBet(betAmount);
            result = house.wagerHalve(player);
        }
        else {
            //if bet remains the same; 
            player.placeBet(betAmount);
            result = house.wagerSame(player);
        }
        //Charlie
        if (result == 1) {
            std::cout << "BIG MONEY! Player wins!\n";
            player.adjustMoney(player.getBet());
        }
        else if (result == 2)
        {
            std::cout << "Dang, better luck next time, house wins\n" << std::endl;
            player.adjustMoney(-player.getBet());
        }
        else {
            std::cout << "It's a tie, that's no fun\n";
        }
        // Spin the player's and house's balls
        //int playerResult = player.getWheel().spin();
        //int houseResult = house.getWheel().spin();


        // Compare results and adjust money accordingly
        //if (playerResult > houseResult) {
        //    player.adjustMoney(player.getBet());
        //    std::cout << "Player wins!" << std::endl;
        //}
        //else if (playerResult < houseResult) {
        //    player.adjustMoney(-player.getBet());
        //    std::cout << "House wins!" << std::endl;
        //}
        //else {
        //    std::cout << "It's a tie. House wins!" << std::endl;
        //}

        // Print player's current money
        std::cout << "Player's current money: " << player.getMoney() << std::endl;
    }

    std::cout << "Game over. You ran out of money!" << std::endl;

    return 0;
}
