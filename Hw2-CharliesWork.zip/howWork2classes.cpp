// Wheel.cpp
#include "Header.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <Windows.h>

using namespace std;
//Eder

Wheel::Wheel(int minVal, int maxVal) : minVal(minVal), maxVal(maxVal) {

}

int Wheel::spin() {
    //initialize the random number generator with the current time as the seed. this will ensure new numbers are generated each time this method is called
    srand(time(0));
    //Program goes too fast, not engaging to the user, this will delay it a bit
    Sleep(1000);
    //generate random number between min and max values set on this class
    int random = rand() % (maxVal + 1 - minVal) + minVal;
    return random;

}


void Wheel::changeRange(int min, int max) {
    this->minVal = min;
    this->maxVal = max;
}

//Steven

Player::Player(int initialMoney) : money(initialMoney) {}

int Player::getMoney() const {
    return money;
}

void Player::setMoney(int newMoney) {
    money = newMoney;
}

void Player::adjustMoney(int amount) {
    money += amount;
}

void Player::placeBet(int betAmount) {
    bet = betAmount;
}

int Player::getBet() const {
    return bet;
}

Wheel& Player::getWheel() {
    return wheel;
}

//Charlie
House::House() {};

Wheel& House::getWheel() {
    return wheel;
}

int House::wagerSame(Player& player) {
    int playerResult = player.getWheel().spin();
    std::cout << "Player Result: " << playerResult << "!\nLet's see what the house has\n";
    int houseResult = getWheel().spin();
    std::cout << "House Result: " << houseResult << "\n";
    if (playerResult > houseResult) {
        return 1;
    }
    else if (playerResult < houseResult) {
        return 2;
    }
    else {
        return 2; 
    }
}
int House::wagerDouble(Player& player) {
    std::cout << "You chose to double, meaning you have to beat the house twice now!\nDealer wins on ties\n";
    int playerResult = player.getWheel().spin();
    std::cout << "Player Result: " << playerResult << "!\nLet's see what the house has\n";
    int houseResult = getWheel().spin();
    if (playerResult <= houseResult) {
        std::cout << "House Result: " << houseResult << "\n*****LOSER!*****\n";
        return 2;
    }
    else {
        std::cout << "*******Let's Go!*******\n";
        std::cout << "dealer gets to go again!\n";
        int houseResult2 = getWheel().spin();
        if (playerResult <= houseResult2) {
            std::cout << "House Result: " << houseResult2 << "\n*****LOSER!*****\n";
            return 2;
        }
        else
        {
            std::cout << "******WINNER******\n";
            return 1; 
        }
    }
}
int House::wagerHalve(Player& player) {
    std::cout << "You chose to halve, meaning you have to beat the house twice now!\nBut if you each win one then nothing changes\nDealer wins on ties\n";
    int playerResult = player.getWheel().spin();
    std::cout << "Player Result: " << playerResult << "!\nLet's see what the house has\n";
    int houseResult = getWheel().spin();
    int houseResult2 = getWheel().spin();
    std::cout << "House Results: " << houseResult <<", "<<houseResult2<<"\n";
    if (playerResult > houseResult && playerResult > houseResult2) {
        std::cout << "******WINNER******\n";
        return 1;
    }
    else if(playerResult > houseResult || playerResult > houseResult2) {
        return 3;
    }
    else {
        std::cout<< "*****LOSER!*****\n";
        return 2;
    }

}